const register = document.getElementById('DoCall')
register.addEventListener('click', () => {
    var status

    fetch('http://localhost/Weboldal/index.php?method=REGISTERPAGE', {
        'method': "POST",
        headers:
        {
            "Content-type": "application/json",
        },
        body: JSON.stringify({
            "name": document.getElementById("name").value,
            "email": document.getElementById("email").value,
            "pass": document.getElementById("pass").value
        })
    })
        .then(res => {
            status = res.status
            return res.text()
        })
        .then(data => {
            alert(data)
            if (status == 200)
                location.href = "http://localhost/Weboldal/index.php?method=WELCOMEPAGE"
        })
        .catch(err => { console.log(err) })
})