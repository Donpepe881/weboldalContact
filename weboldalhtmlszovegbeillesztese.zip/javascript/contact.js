
async function sendContact() {

    fetch('http://localhost/Weboldal/index.php?method=CONTACTINPUTPAGE', {
        'method': "POST",
        headers:
        {
            "Content-type": "application/json",
        },
        body: JSON.stringify({
            "contactName": document.getElementById("contactName").value,
            "contactEmail": document.getElementById("contactEmail").value,
            "contactTextarea": document.getElementById("contactTextarea").value
        })
    })
        .then(res => res.text())
        .then(data => {
            console.log(data);
            var target = data.getElementById("result");
            var targetErrorText = data.getElementsByClassName("error").value;
            var targetSuccessText = data.getElementsByClassName("success").value;
            if (target.className == "error") {
                target.innerHTML = targetErrorText;
                target.setAttribute("class", "error");
            }
            else {
                target.innerHTML = targetSuccessText;
                target.setAttribute("class", "success");
            }
        })
        .catch(err => { console.log(err) })
}