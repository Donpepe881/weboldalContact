<?php

class ContactInputPage implements IHTTPPOST, IHTTPGET
{

    public function POST(): void
    {

        View::Init("contactInput.html");
        $input = file_get_contents("php://input");
        $json = json_decode($input, true);

        if (is_array($json)) {

            if (isset($json["contactName"]) && isset($json["contactEmail"]) && isset($json["contactTextarea"]) && trim($json["contactName"]) != "" && trim($json["contactEmail"]) != "" && trim($json["contactTextarea"]) != "") {

                $contactname = htmlspecialchars(trim($json["contactName"]));
                $email = htmlspecialchars(trim($json["contactEmail"]));
                $contactText = htmlspecialchars(trim($json["contactTextarea"]));

                if (ModelDB::Contact($contactname, $email, $contactText)) {

                    View::getBaseTemplate()->AddData("RESULT", "Sikeres üzenetküldés");
                    View::getBaseTemplate()->AddData("RESULTCLASS", "success");

                } else {

                    View::getBaseTemplate()->AddData("RESULT", "Sikertelen üzenetküldés!");
                    View::getBaseTemplate()->AddData("RESULTCLASS", "error");
                }
            } else {

                View::getBaseTemplate()->AddData("RESULT", "Minden mező kitöltése szükséges!");
                View::getBaseTemplate()->AddData("RESULTCLASS", "error");
            }
        } else {

            View::getBaseTemplate()->AddData("RESULT", "Nem értelmező bemenet!");
            View::getBaseTemplate()->AddData("RESULTCLASS", "error");
        }
    }

    public function GET(): void
    {

        View::Init("contactInput.html");
    }
}