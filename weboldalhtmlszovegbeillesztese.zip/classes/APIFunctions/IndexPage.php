<?php

class IndexPage implements IHTTPGET
{

    public function GET(): void
    {
        VIew::Init("index.html");
    }


}