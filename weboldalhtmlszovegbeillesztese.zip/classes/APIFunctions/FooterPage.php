<?php

class FooterPage implements IHTTPGET
{

    public function GET(): void
    {
        View::Init("footer.html");
    }


}