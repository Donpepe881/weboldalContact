<?php

class WelcomePage implements IHTTPGET
{

    public function GET(): void
    {

        View::Init("welcome.html");
        $username = $_SESSION["name"];

        View::getBaseTemplate()->AddData("USERNAME", $username . "!");
    }
}