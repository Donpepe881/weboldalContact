<?php

class ContactPage implements IHTTPGET
{

    public function GET(): void
    {
        View::Init("contact.html");
    }
}