<?php

abstract class ModelDB
{
    private static PDO $pdo;

    public static function Connect(): void
    {
        global $conf;
        try {
            self::$pdo = new PDO("mysql:host={$conf["DBHost"]};dbname={$conf["DBName"]};port={$conf["DBPort"]}", $conf["DBUser"], $conf["DBPass"]);
            self::$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (Exception $ex) {
            throw new DBException("Az adatbázis kapcsolódás sikertelen!", $ex);
        }
    }

    public static function GetPage(string $key): bool|array
    {
        try {
            $result = self::$pdo->query("SELECT * FROM `pages`  WHERE `key` = " . self::$pdo->quote($key));
            if ($result->rowCount() == 1) {
                $data = $result->fetchAll(PDO::FETCH_DEFAULT)[0];
                $result->closeCursor();
                return $data;
            }
            return false;
        } catch (Exception $ex) {
            throw new DBException("Sikertelen oldal lekérdezés, $ex");
        }
    }


    public static function Login(): array
    {
        $result = self::$pdo->query("SELECT `name`,`email`, `pass` FROM `users`");
        $datas = $result->fetchAll(PDO::FETCH_BOTH);
        $result->closeCursor();
        return $datas;
    }

    public static function Register(string $name, string $email, string $pass): bool
    {
        try {
            $prep = self::$pdo->prepare("INSERT INTO `users` VALUES (:name, :email, :pass)");
            $prep->bindParam(":name", $name, PDO::PARAM_STR);
            $prep->bindParam(":email", $email, PDO::PARAM_STR);
            $prep->bindParam(":pass", $pass, PDO::PARAM_STR);

            return $prep->execute();
        } catch (Exception $ex) {
            throw new DBException("Sikertelen regisztráció!", $ex);
        }
    }

    public static function Contact(string $contactName, string $contactEmail, string $contactTextarea): bool
    {
        try {
            $prep = self::$pdo->prepare("INSERT INTO `contact` VALUES (NULL, :contactName, :contactEmail, :contactTextarea)");
            $prep->bindParam(":contactName", $contactName, PDO::PARAM_STR);
            $prep->bindParam(":contactEmail", $contactEmail, PDO::PARAM_STR);
            $prep->bindParam(":contactTextarea", $contactTextarea, PDO::PARAM_STR);

            return $prep->execute();
        } catch (Exception $ex) {
            throw new DBException("Sikertelen üzenetküldés", $ex);
        }
    }

}