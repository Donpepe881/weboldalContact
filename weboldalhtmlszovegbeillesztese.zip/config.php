<?php

$conf["methodParam"] = "method";
//Database
$conf["DBHost"] = "localhost";
$conf["DBName"] = "szstrudi";
$conf["DBPort"] = "3307";
$conf["DBUser"] = "pedro";
$conf["DBPass"] = "123456aA";