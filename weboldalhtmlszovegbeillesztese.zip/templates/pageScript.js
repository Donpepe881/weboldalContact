//fetch("url", {opciók}).then(response => response.text).then(textHtml => document.getElementById("valami").innerHTML += textHtml); --> tehát a "valami" ID-val rendelkező container-be fogja a JS belerakni a kapott szöveget, ami HTML, tehát a böngésző megjeleníti. (+=-vel írtam, tehát ha már volt ott valami a mögé szúrja be, de felül is lehet írni, akkor kicseréli)


async function Index() {
    fetch("http://localhost/Weboldal/index.php?method=INDEXPAGE",
        {
            method: "GET",

        })
        .then(response => response.text);
}







//fetch("url", {opciók}).then(response => response.text).then(textHtml => document.getElementById("valami").innerHTML += textHtml); --> tehát a "valami" ID-val rendelkező container-be fogja a JS belerakni a kapott szöveget, ami HTML, tehát a böngésző megjeleníti. (+=-vel írtam, tehát ha már volt ott valami a mögé szúrja be, de felül is lehet írni, akkor kicseréli)


async function Welcome() {
    fetch("http://localhost/Weboldal/index.php?method=WELCOMEPAGE",
        {
            method: "GET",

        })
        .then(response => response.text());
    //then(textHtml => document.getElementById("register").innerHTML += textHtml);
}

async function MainMenu() {
    fetch("http://localhost/Weboldal/index.php?method=MAINMENUPAGE",
        {
            method: "GET",

        })
        .then(response => response.text()).
        then(textHtml => document.getElementById("menu").innerHTML += textHtml);
}



async function Menu() {
    fetch("http://localhost/Weboldal/index.php?method=MENUPAGE",
        {
            method: "GET",
        })
        .then(response => response.text()).
        then(textHtml => document.getElementById("menu").innerHTML += textHtml);
}


async function ContactInput() {
    fetch("http://localhost/Weboldal/index.php?method=CONTACTINPUTPAGE",
        {
            method: "GET",
        })
        .then(response => response.text()).
        then(textHtml => document.getElementById("contactinput").innerHTML += textHtml);
}



async function Footer() {
    fetch("http://localhost/Weboldal/index.php?method=FOOTERPAGE",
        {
            method: "GET",

        })
        .then(response => response.text()).
        then(textHtml => document.getElementById("footer").innerHTML += textHtml);
}





