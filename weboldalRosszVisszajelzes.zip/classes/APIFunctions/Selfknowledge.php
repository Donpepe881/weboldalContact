<?php

class Selfknowledge implements IHTTPGET
{
    public function GET(): void
    {
        View::Init("selfknowledge.html");
    }
}