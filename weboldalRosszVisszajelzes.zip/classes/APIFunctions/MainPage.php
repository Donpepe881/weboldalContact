<?php

class MainPage implements IHTTPGET
{

    public function GET(): void
    {
        VIew::Init("main.html");
    }

}