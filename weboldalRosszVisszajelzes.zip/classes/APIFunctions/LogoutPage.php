<?php

class LogoutPage implements IHTTPGET
{

    public function GET(): void
    {
        if (!isset($_COOKIE['user'])) {
            echo "You are not logged in!!!";
            exit();
        }
        unset($_SESSION['user']);
        session_destroy();
        setcookie('user', false);
        echo "You are logged out!!! " . session_start();
        header("/Weboldal/index.php?method=INDEXPAGE");
        exit();
    }

}