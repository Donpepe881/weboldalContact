<?php
abstract class Controller
{

    public static function Init(): void
    {
        ModelDB::Connect();
        View::Init("index.html");
    }

    public static function Route()
    {
        if (isset($_GET["page"])) {
            $page = htmlspecialchars($_GET["page"]);
        } elseif (isset($_SESSION["name"])) {
            $page = "welcome";
        } else {
            $page = "login";
        }

        $pageData = ModelDB::GetPage($page);
        if ($pageData != false) {

            $subPageTemplate = call_user_func(array(ucfirst($page) . "Page", "Run"));
            if ($pageData[2] != "false") {
                $pageTemplate = Template::Load("{$pageData[2]}.html");
                $pageTemplate->AddData("PAGECONTENT", $subPageTemplate->Render());
            } else {
                $pageTemplate = $subPageTemplate;
            }
        } else {
            $pageTemplate = self::Error404Controller();
        }
        View::getBaseTemplate()->AddData("CONTENT", $pageTemplate->Render());
    }

    private static function Error404Controller(): Template
    {
        $template = Template::Load("notFound.html");
        $template->AddData("CONTENT", "Az oldal nem létezik!");
        $template->AddData("TITLE", "A megadott oldal nem található!");
        return $template;
    }

    public static function DoCall(): void
    {
        global $conf;
        if (isset($_GET[$conf["methodParam"]])) {
            $class = htmlspecialchars($_GET[$conf["methodParam"]]);
            if (class_exists($class, true)) {

                $method = $_SERVER["REQUEST_METHOD"];
                $interfaces = class_implements($class, true);

                if ($interfaces !== false && in_array("IHTTP" . $method, $interfaces)) {
                    $obj = new $class();
                    $obj->$method();
                } else {
                    View::Init("error.html"); //Már itt is mindenhol HTML kell legyen
                    View::getBaseTemplate()->AddData("RESULT", "A hívott szolgáltatás létezik, de ezen a metodikán nem szolgál ki!");
                }
            } else {
                View::Init("error.html");
                View::getBaseTemplate()->AddData("RESULT", "A hívott szolgáltatás ($class) nem létezik!");
            }
        } else {
            View::Init("error.html");
            View::getBaseTemplate()->AddData("RESULT", "Nincs kijelölt szolgáltatás!");
        }
    }
}
