
async function sendContact() {

    fetch('http://localhost/Weboldal/index.php?method=CONTACTPAGE', {
        'method': "POST",
        headers:
        {
            "Content-type": "application/json",
        },
        body: JSON.stringify({
            "contactName": document.getElementById("contactName").value,
            "contactEmail": document.getElementById("contactEmail").value,
            "contactTextarea": document.getElementById("contactTextarea").value
        })
    })
        .then(res => res.text())
        .then(data => {
            console.log(data);
            var target = document.getElementById("result");
            if (target.className == "error") {
                //target.innerHTML = "Sikertelen üzenetküldés";
                //target.setAttribute("class", "error");
            }
            else {
                target.innerHTML = "Sikeres üzenetküldés";
                target.setAttribute("class", "success");
            }
        })
        .catch(err => { console.log(err) })
}