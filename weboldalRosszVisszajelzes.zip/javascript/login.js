const login = document.getElementById('DoCall')
login.addEventListener('click', () => {
    var status
    fetch('http://localhost/Weboldal/index.php?method=LOGINPAGE', {
        'method': 'POST',
        headers:
        {
            "Content-type": "application/json",
        },
        body: JSON.stringify({
            "email": document.getElementById("email").value,
            "pass": document.getElementById("pass").value
        }),
        mode: 'cors',
        credentials: 'include'
    })
        .then(res => {
            status = res.status
            console.log('user cookies is ')
            console.log(res.headers.get('user'))
            return res.text()
        })
        .then(data => {
            console.log(document.cookie)
            alert(data)
            if (status == 200)
                location.href = "/Weboldal/index.php?method=WELCOMEPAGE"
        })
        .catch(err => {

            console.log(err)
        })

})